"""Runs the web version of chemprop locally."""

from chemprop.web import chemprop_web


if __name__ == '__main__':
    chemprop_web()
