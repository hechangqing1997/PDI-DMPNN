.. _nn_utils:

Neural Network Utility Functions
================================

`chemprop.nn_utils.py <https://github.com/chemprop/chemprop/tree/master/chemprop/nn_utils.py>`_ contains utility funtions specific to neural networks.

.. automodule:: chemprop.nn_utils
   :members:
